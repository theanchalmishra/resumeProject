import "../App.css";
const Footer = () => {
    return (
        <div className="footer">
            <div className="f_section">
                <div className="f_link">
                    <div className="f_link_div">
                    
                    <a href="/coinGecko">
                            <h6>Coinmarketcap</h6>
                        </a>

                        <a href="/coinGecko">
                            <h6>coinGecko</h6>
                        </a>

                        <a href="/advertise with us">
                            <h6>Advertise with Us</h6>
                        </a>
                        <a href="/documentation">
                            <h6>Documentation</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Protocol</h4>
                        <a href="/apply for dropzone">
                            <h6>Apply for DropZone</h6>
                        </a>
                        <a href="/apply for launchpad">
                            <h6>Apply for Launchpad</h6>
                        </a>

                        <a href="/apply for fusion pool">
                            <h6>Apply for Fusion Pool</h6>
                        </a>
                        <a href="/list your token">
                            <h6>List Your token</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Support</h4>
                        <a href="/terms">
                            <h6>Terms of Use</h6>
                        </a>

                        <a href="/privacy">
                            <h6>Privacy</h6>
                        </a>

                        <a href="/disclaimer">
                            <h6>Disclaimer</h6>
                        </a>
                        <a href="/faqs">
                            <h6>FAQs</h6>
                        </a>
                    </div>
                  

                    <div className="f_link_div">
                   
                        <h4>Community</h4>
                        <div class="Social-media">
                        <a href="/twit">
                        <h6>twitter</h6></a>
                        <a href="/youtube">
                        <h6>Youtube</h6></a>
                        <a href="/insta">
                        <h6>Linkdin</h6></a>
                        <a href="/telegram">
                        <h6>Telegram</h6></a>
                        </div>
                        </div>
                        </div>
                    </div>
                </div>
        
    )
};

export default Footer;