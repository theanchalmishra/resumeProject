import React from 'react';
import "../App.css";
import Seedx from './Seedx';
const Header = () => {
  return (
    <div class="banner-upper  m-0 p-0 ">
      <div className='my-banner m-0 p-0'>

        <div className=''>
          <div class="banner-upper-text text-white"><span>A Complete</span>
            <h2 className="home-main-text">Decentralised <span className="text-pink">Finance</span></h2>

            <div class="h4 mt-3">The decentralised Finance SEEDx offers traders an innovative method.</div>
            <div class="h5 mt-3">Get rental liquidity for token launches on Amm dex anywhere, : Uniswap, pancakeswap,</div><p> raydium</p>
            <h5 class="mt-3"><span class="fs-14">Traders can amplify their positions using borrowed liquidity, maximizing potential returns.</span></h5>
          </div>
          <div class="banner-upper-button">
            <a class="btn btn btn_customised" href="/trade/seedx-inrx">Trade</a>
            <a class="btn btn-darker" href="/Pools">Borrow Liquidity</a>
            <a class="btn btn-darker" href="/Swap">Leverage SWap</a>
            <a class="btn btn-darker" href="/LiquidTrade">Liquid Trade</a>
            <a class="btn btn-darker" href="/Nfts">SNS NFTs</a>
            <a class="btn btn-darker" href="/bitbnb">Win BNB</a>
          </div>
      
        </div>
        <div class="homepage-stats col-lg-4">
          <div class="border-neutral-800-dark &quot;text-xs py-2 px-4 border-b ">🎉 How big are we?</div>
          <div class="row row-cols-1 row-cols-md-2 gap-6">
            <div class="col-6 py-3 text-center">
              <div class="text-4xl leading-relaxed uppercase">$1.5B</div>
              <div class="text-color">Total Liquidity Raised</div>
            </div>

            <div class="col-6 py-3 text-center">
              <div class="transition-all flex-1 flex flex-col items-center">
                <div class="text-4xl leading-relaxed uppercase">28K</div>
                <div class="text-color">Total Projects</div>
              </div>
            </div>

            <div class="col-6 py-3 text-center">
              <div class="transition-all flex-1 flex flex-col items-center">
                <div class="text-4xl leading-relaxed uppercase">3.2M</div>
                <div class="text-color">Total Participants</div>
              </div>
              <a class="text-brand" rel="nofollow noreferrer" href="/" target="_blank">SEEDx</a>
            </div>
            <div class="col-6 py-3 text-center">
              <div class="transition-all flex-1 flex flex-col items-center">
                <div class="text-4xl leading-relaxed uppercase">$924.9M</div>
                <div class="text-xs">Total Values Locked</div>
                <a href="https://www.coingecko.com/en/coins/pinksale" target="_blank" rel="nofollow noreferrer" class="text-brand">$ 0</a>
              </div>
            </div>

          </div>
        </div>
 </div>
 
 <div className="container1">
      <div className="title1">
        <h2>GamePad</h2>
        <span>$chainLink VRF Powered Decentralize Gaming area for Players</span>
      </div>
      <div className="content1">
        <div className="cards1">
        <div className='size'>
          <h6>
          Luck, VRFs, and multiplied rewards: the essence of decentralized gaming's allure.
          </h6></div>
        </div>
        <div className="cards1">
            <div className='size'>
          <h6>
          Chance, VRFs, and multiplied rewards beckon adventurers to decentralized gaming's realm.
          </h6></div>
        </div>
        <div className="cards1">
        <div className='size'>
          <h6>
          In peer-to-peer games, randomness reigns, where anyone can win limitless treasures.
          </h6></div>
        </div>
      </div>
    </div>
</div>
)
};


export default Header;