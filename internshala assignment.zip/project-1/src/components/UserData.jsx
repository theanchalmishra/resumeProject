const UserData = ({users}) => {
    console.log(users,"sdfdgh")
    return (
        <>
        {
        users.map((curUser)=>{
            //const {id,image,name,symbol}=curUser;
            const {id,image,name,symbol}=curUser;
            return (
        
                <tr class="market-row">
            <div className="logo">
              <img src={image} height='50px' width='50px' alt="logo" />
            </div>
            <td class="market-cell">
                {id}
            </td>
            <td class="market-cell" align="left">0% ↑</td>
            <td class="market-cell">{symbol}</td>
            <td class="market-cell"><button class="market-button">Trade</button></td>
          </tr>
            )
        })
       
    }
    </>
    )
}
export default UserData;
