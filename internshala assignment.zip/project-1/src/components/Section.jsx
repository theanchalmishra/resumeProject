
import React from 'react';
import "../App.css";
const Section = () => {
  return (
    <div className="container1">
      <div className="title1">
        <h2>Get more done with SEEDx</h2>
      </div>
      <div className="content1">
        <div className="card1">
            <h5>No surprises or hidden fees</h5>
          <h6>
          We don't change anything to list on an exchange, do airdops, or make tokens.
          </h6>
        </div>
        <div className="card1">
            <h5>PreFunded AcceleRaytor</h5>
          <h6>
            Grab Seed investment for a unique project from SEEDx DA0 Community.
          </h6>
        </div>
        <div className="card1">
            <h5>Scratch Reward</h5>
          <h6>
            Participate in Community event, accomplish event's objective and get a prize of arbitrary value.
          </h6>
        </div>
      </div>
    </div>
  );
};

export default Section;