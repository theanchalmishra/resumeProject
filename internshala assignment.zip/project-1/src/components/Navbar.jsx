import { Link, NavLink } from "react-router-dom";
import "../App.css";
const Navbar = () => {
    return (
        <>
            <div className="my-navbar">
                <nav>
                    <ul>
                        <li>
                            <NavLink to={"/"}> Home </NavLink>
                        </li>
                        <li>
                            <NavLink to="/trade"> Exchange </NavLink>
                        </li>
                        <li>
                            <NavLink to="/leverage"> Swap </NavLink>
                        </li>
                        <li>
                            <NavLink to="/governance"> Governance </NavLink>
                        </li>
                        <li>
                            <NavLink to="/propfund"> PropFund </NavLink>
                        </li>
                        <li>
                            <NavLink to="/tokens"> Tokens </NavLink>
                        </li>
                        <li>
                            <NavLink to="/Scratch"> Scratch </NavLink>
                        </li>
                     
                    </ul>
                </nav>
                <button class="btn btn-sm btn-grad3">Connect Wallet</button>
                </div>
        </>
    )
};
export default Navbar;
