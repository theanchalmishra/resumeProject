import React from 'react';
import "../App.css";
const Seedx = () => {
  return (
      <div className="container1">
      <div className="title1">
        <h2>Get more done with SEEDx</h2>
      </div>
      <div className="content1">
          <div className="cards2">
            <div className='size1'>
            <h5>No surprises or hidden fees</h5> </div>
            <div className='span'>
          <span>
          Luck, VRFs, and multiplied rewards: the essence of decentralized gaming's allure.
          </span></div>
        </div>
       
        <div className="cards2">
            <div className='size1'>
            <h5>PreFunded AcceleRaytor</h5> </div>
            <div className='span'>
          <span>
            Grab Seed investment for a unique project from SEEDx DA0 Community.
          </span></div>
        </div>
        
        <div className="cards2">
        <div className='size1'>
        <h5>Scratch Reward</h5></div>
        <div className='span'>
          <span>
            Participate in Community event, accomplish event's objective and get a prize of arbitrary value.
          </span></div>
         
        </div>
      </div>
     
    </div>
    
  );
};

export default Seedx;