/*import React from 'react'
import AM from './image/AM.png'
function ImagesDemo() {
    return (
        <>
        <div>ImagesDemo</div>
        <img src={AM} height='50' width='50'/>
    </>
    )
}
export default ImagesDemo*/