
import React, { useEffect, useState } from 'react';
import AMlogo from "../src/image/AM.png";
import Navbar from './components/Navbar';
import Footer from './components/footer';
import Seedx from './components/Seedx';
import Header from './components/Header';
import Section from './components/Section';
import UserData from './components/UserData';
import { getTokens } from './apishanlers/apis';
import { BrowserRouter } from 'react-router-dom';
import AllRoutes from './AllRoutes';


const App = () => {
  const [list, setList] = useState([])

  useEffect(() => {
    (async () => {
      try {
        const arr = await getTokens();
        setList(arr);
        console.log(arr, "token list")
      } catch (e) {
        console.log(e, "Error in usesdsf")
      }
    })();

  }, [])

  return (

    <>
      <BrowserRouter>

        <Navbar />

        <AllRoutes />
      </BrowserRouter>

    </>
  )
};


export default App;