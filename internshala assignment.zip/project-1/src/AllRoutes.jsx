import { BrowserRouter, Routes, Route} from "react-router-dom"
import Home from "./pages/Home"
import Exchange from "./Exchange"
import TradingPage from "./pages/TradingPage"
import LeverageSwap from "./pages/LeverageSwap"
import ListToken from "./pages/ListToken"
import GovernancePage from "./pages/GovernancePage"
import PropFund from "./pages/PropFund"
import TokensPage from "./pages/TokensPage"
import Scratch from "./pages/Scratch"

// import Error from "./Error"
const AllRoutes = () => {
    return (
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/menu" element={<Exchange />} />
                <Route path="/trade" element={<TradingPage />} />
                <Route path="/leverage" element={<LeverageSwap/>} />
                <Route path="/Governance" element={<GovernancePage/>} />
                <Route path="/PropFund" element={<PropFund/>} />
                <Route path="/Exchange" element={<ListToken/>} />
                <Route path="/Tokens" element={<TokensPage/>} />
                <Route path="/Scratch" element={<Scratch/>} />
            
                
                {/* <Route path="/exchange" element={<Governance />} />  */}
                {/*<Route path="*" element={<Error />} /> */}
            </Routes>

    )
}

export default AllRoutes