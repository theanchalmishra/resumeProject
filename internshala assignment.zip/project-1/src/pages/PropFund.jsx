import React, { useState } from 'react';
import './app5.css';
import Footer from '../components/footer';
const PropFund = () => {
  const [selectedRouter, setSelectedRouter] = useState(null);
  const [selectedCoin, setSelectedCoin] = useState(null);

  const handleRouterChange = (router) => {
    setSelectedRouter(router);
  };

  const handleCoinChange = (coin) => {
    setSelectedCoin(coin);
  };
  return (
<div className="container1">
    <div class="bg-headr2 py-0 px-2">
      <ul class="d-flex gap-3 list-unstyled align-items-center mb-0"><li class="text-sm font-medium d-flex items-center gap-1">
        <div>⚡</div><div>Trending</div></li>
        <li class="flex-1 overflow-x-auto"><ul class="d-flex items-center">
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#1</span>
          <a class="text-brand" href="/trade/SHIB-INRx">SHIB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#2</span>
          <a class="text-brand" href="/trade/Pepe-INRx">Pepe</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#3</span>
          <a class="text-brand" href="/trade/SEEDx-INRx">SEEDx</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#4</span>
          <a class="text-brand" href="/trade/DOGE-INRx">DOGE</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#5</span>
          <a class="text-brand" href="/trade/Link-INRx">Link</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#6</span>
          <a class="text-brand" href="/trade/ETH-INRx">ETH</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#7</span>
          <a class="text-brand" href="/trade/stBNB-INRx">stBNB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#8</span>
          <a class="text-brand" href="/trade/Tron-INRx">Tron</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#9</span>
          <a class="text-brand" href="/trade/Matic-INRx">Matic</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#10</span>
          <a class="text-brand" href="/trade/USDT-INRx">USDT</a></li>
        </ul>
      </li>
    </ul>

    </div>
    <div className='HeaderSection'>
    <div className='gif'>
    <img src="https://cdn.dribbble.com/users/72535/screenshots/2630779/data_visualization_by_jardson_almeida.gif" height="420px" width="880px" alt="logo"></img></div>
    

    <div class="row"><div class="col-lg-12"><div class="card mb-2"><div class="card1-body"><div class="d-flex justify-content-between align-items-center mb-2">
     <div class="card-header"><h5 class="mb-0 fs-16">Total Supply</h5><div><img src="https://seedx.app/image/INRx_72x.png" width="30px" height="30px"alt=""></img> </div></div></div>

     <div class="d-flex justify-content-between mb-3 align-items-center"><div class="d-flex gap-2 align-items-center"><div class="progress_dot available_liq"></div>
     </div><div>₹ 700.00</div></div>
     <div class="d-flex justify-content-between mb-3 align-items-center"><div class="d-flex gap-2 align-items-center"><div class="progress_dot available_liq"></div><div class="text-color">Available Liquidity</div></div><div>₹ 900.00</div></div>


     <div class="assets_scrollbar no_scrollbar "></div>
      <div></div></div></div></div></div>


</div>
     <div className='Section'>
     <div class="row"><div class="col-lg-12"><div class="card mb-2"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2"></div>
     <div class="card-header px-0 mb-2"><h5 class="mb-0 fs-16">Currently Borrowed</h5></div>
     <img src="https://www.actionforex.com/wp-content/uploads/2024/08/roboforex2024082011.gif" height="280px" width="430px" alt="logo"></img>
     <a href="#" class="btn btn-grad4">Repay</a>
     </div></div></div></div>
     <div class="row"><div class="col-lg-12"><div class="card mb-2"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2">
     <div class="card-header px-0 mb-2"><h5 class="mb-0 fs-16">Position Summary</h5></div>
      <div></div></div><div class="d-flex justify-content-between align-items-center mt-5"><div><div class="d-flex align-items-center">
      <div><div class="text-color">Decentralised Collateral Value</div><div>₹ 1.050.00</div></div>
        </div></div></div><div class="d-flex justify-content-between align-items-end mt-5"><div class="adv_serch"><div class="dropdown"><div class="text-muted">Borrow Capacity</div></div><span>₹1.000.00</span></div></div>
        <div class="d-flex justify-content-between align-items-end mt-5"><div class="adv_serch"><div class="dropdown"><div class="text-muted">Liquidation</div></div><span>₹700.00</span></div></div>
        

        
        <a href="#" class="btn btn-grad5">Repay</a>
        </div></div></div></div>
     <div class="row"><div class="col-lg-12"><div class="card mb-2"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2">
     <div class="card-header"><h5 class="mb-0 fs-16">Active PropFund Trades</h5><div class="text-color fs-13">Based on connected Trust Wallet</div></div></div>
     <div class="assets_scrollbar no_scrollbar "><h6 class="text-center">No Active Trades</h6></div>
      <div></div></div>
      </div></div></div></div>

      <div className='Section1'>
      <div class="row"><div class="col-lg-12"><div class="card1 mb-2"><div class="card1-body"><div class="d-flex justify-content-between align-items-center mb-2">
     <div class="card-header"><h5 class="mb-0 fs-16">Total Supply</h5><div><img src="https://seedx.app/image/INRx_72x.png" width="30px" height="30px"alt=""></img> </div></div></div>

     <div class="d-flex justify-content-between mb-3 align-items-center"><div class="d-flex gap-2 align-items-center"><div class="progress_dot available_liq"></div>
     <div class="progress_dot total_borrow"></div>
     <div class="text-color">Total Borrow</div></div><div>₹ 700.00</div></div>
     <div class="d-flex justify-content-between mb-3 align-items-center"><div class="d-flex gap-2 align-items-center"><div class="progress_dot available_liq"></div>
     <div class="progress_dot total_borrow"></div>
     <div class="text-color">Available Liquidity</div></div><div>₹ 900.00</div></div>
     <div class="assets_scrollbar no_scrollbar "></div>
     <div style={{ width: '100%', backgroundColor: 'gray' }}><div style={{ width: '30%', height: '20px', backgroundColor: 'pink' }}></div></div>
      <div></div></div></div></div></div>



      <div class="row"><div class="col-lg-12"><div class="card1 mb-2"><div class="card1-body"><div class="d-flex justify-content-between align-items-center mb-2">
     <div class="card-header"><h5 class="mb-0 fs-16">Last 24</h5></div></div>

     <div class="my-3"><div class="text-color">Vol</div><div>₹ 1.192.00</div></div>
     <div class="text-color">Supply</div><div><img src="https://seedx.app/image/INRx_72x.png" width="20px" height="10px"alt=""></img> </div>
     <div className='text1'>
     <div><div class="text-color">Total Borrow</div><span>₹ 700.00</span></div>
   </div>
     <div class="assets_scrollbar no_scrollbar "></div>
      <div></div></div></div></div></div>


      <div className='box3'>
      <div class="row"><div class="col-lg-12"><div class="card1 mb-2"><div class="card1-body"></div><div class="d-flex justify-content-between align-items-center mb-2">
     <div class="card-header"><h5 class="mb-0 fs-16">Overview</h5></div></div>
     <div className='text'>
    
    
     <div class="d-flex justify-content-between mb-3 align-items-center"><div class="d-flex gap-2 align-items-center"><div class="progress_dot available_liq"></div>
     <div class="progress_dot total_borrow1"></div>
     <div class="my-3"><div class="text-color">Total Borrowing</div><div>₹₹ 700.00</div></div></div>
     <div><img src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTImDunfObAkUG-egJTKOjJAJ5GviH9lElT-_POdS2PP4wVXvPp"width="140px" height="65px"alt=""></img> </div>
     </div>
     </div>


     <div class="d-flex justify-content-between mb-3 align-items-center"><div class="d-flex gap-2 align-items-center"><div class="progress_dot available_liq"></div>
     <div class="progress_dot total_borrow2"></div>
     <div class="my-3"><div class="text-color">Total Collaletral</div><div>₹₹ 700.00</div></div></div>
     <div><img src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTImDunfObAkUG-egJTKOjJAJ5GviH9lElT-_POdS2PP4wVXvPp"width="140px" height="65px"alt=""></img> </div>
     </div>
     
      <div></div></div></div></div></div></div>
      <div className="footer">
            <div className="f_section">
                <div className="f_link">
                    <div className="f_link_div">
                        <h4>About</h4>
                        <a href="/coinmarketcap">
                            <h6>Coinmarketcap</h6>
                        </a>

                        <a href="/coinGecko">
                            <h6>coinGecko</h6>
                        </a>

                        <a href="/advertise with us">
                            <h6>Advertise with Us</h6>
                        </a>
                        <a href="/documentation">
                            <h6>Documentation</h6>
                        </a>
                    </div>
                    <div className="f_link_div">
                        <h4>Protocol</h4>
                        <a href="/apply for dropzone">
                            <h6>Apply for DropZone</h6>
                        </a>
                        <a href="/apply for launchpad">
                            <h6>Apply for Launchpad</h6>
                        </a>

                        <a href="/apply for fusion pool">
                            <h6>Apply for Fusion Pool</h6>
                        </a>
                        <a href="/list your token">
                            <h6>List Your token</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Support</h4>
                        <a href="/terms">
                            <h6>Terms of Use</h6>
                        </a>

                        <a href="/privacy">
                            <h6>Privacy</h6>
                        </a>

                        <a href="/disclaimer">
                            <h6>Disclaimer</h6>
                        </a>
                        <a href="/faqs">
                            <h6>FAQs</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Community</h4>
                        <div class="Social-media">
                        <a href="/twit">
                        <h6>twitter</h6></a>
                        <a href="/youtube">
                        <h6>Youtube</h6></a>
                        <a href="/insta">
                        <h6>Linkdin</h6></a>
                        <a href="/telegram">
                        <h6>Telegram</h6></a>
                        </div>
                    </div>
                </div>
            </div>
        
      </div>
  </div>
    
  );
};

export default PropFund;