import React, { useState } from 'react';
import './app1.css';
const TradingPage = () => {
  const [selectedRouter, setSelectedRouter] = useState(null);
  const [selectedCoin, setSelectedCoin] = useState(null);

  const handleRouterChange = (router) => {
    setSelectedRouter(router);
  };

  const handleCoinChange = (coin) => {
    setSelectedCoin(coin);
  };
  return (
    <div class="bg-headr2 py-0 px-2">
      <ul class="d-flex gap-3 list-unstyled align-items-center mb-0"><li class="text-sm font-medium d-flex items-center gap-1">
        <div>⚡</div><div>Trending</div></li>
        <li class="flex-1 overflow-x-auto"><ul class="d-flex items-center">
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#1</span>
          <a class="text-brand" href="/trade/SHIB-INRx">SHIB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#2</span>
          <a class="text-brand" href="/trade/Pepe-INRx">Pepe</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#3</span>
          <a class="text-brand" href="/trade/SEEDx-INRx">SEEDx</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#4</span>
          <a class="text-brand" href="/trade/DOGE-INRx">DOGE</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#5</span>
          <a class="text-brand" href="/trade/Link-INRx">Link</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#6</span>
          <a class="text-brand" href="/trade/ETH-INRx">ETH</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#7</span>
          <a class="text-brand" href="/trade/stBNB-INRx">stBNB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#8</span>
          <a class="text-brand" href="/trade/Tron-INRx">Tron</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#9</span>
          <a class="text-brand" href="/trade/Matic-INRx">Matic</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#10</span>
          <a class="text-brand" href="/trade/USDT-INRx">USDT</a></li>
        </ul>
      </li>
    </ul>
    <div className='HeaderSection'>
    <div className='gif2'>
    <img src="https://ximg.magic.store/kreHY_OKtKXVDr5xWAJW3O9TtUGvNgWubDCzRuovO9M/rs:fill:1200:550:0/dpr:1/g:ce/f:webp/q:60/czM6Ly9wcm9kLW1hZ2ljLXN0b3JlLWltYWdlcy81MTBlNWEwZS1hOWM5LTRjY2MtODIzYi1lYWQ3NzExN2FjODE" height="160px" width="640px" alt="logo"></img></div>
    </div>
    <div className='border'>
    <div class="m7w29c O8VmIc tIvQIf"><noscript><div class="HB1eCd-X3SwIb-haAclf"><div class="HB1eCd-X3SwIb-i8xkGf"><div class="tk3N6e-cXJiPb tk3N6e-cXJiPb-TSZdd tk3N6e-cXJiPb-GMvhG">JavaScript isn't enabled in your browser, so this file can't be opened. Enable and reload.</div></div></div></noscript><div class="JH79cc RVEQke b33AEc"></div><div class="N0gd6"><div class="ahS2Le"><div class="F9yp7e ikZYwf LgNcQe" dir="auto" role="heading" aria-level="1">SEEDx Orderbook Listing Request<span></span></div></div><div class="cBGGJ OIC90c" dir="auto"><ul><li><b>In emergencies please contact us at <a href="http://info@seedx.app">info@seedx.app</a>&nbsp;</b></li><li><b>Listing Fee -&gt; 2000$ equivalent SEEDx</b></li></ul></div><div jsname="F0H8Yc" class="liS6Hc"></div></div><div class="zAVwcb"></div><div class="DqBBlb"><div class="Oh1Vtf"><div class="tMRmsd" id="wSDd7b"><div class="ut7aeb"><div class="eAQI0e"><span class="EbMsme">mishra.anchal9305@gmail.com</span> <a href="https://accounts.google.com/AccountChooser?continue=https://docs.google.com/forms/d/e/1FAIpQLSf3Atn9ntsJkIVRh1puYaBj4uA9OzD_Ba6dhfuhmj6UkYkdBA/viewform&amp;service=wise" aria-describedby="wSDd7b" class="jZZ5Nd">Switch accounts</a></div></div><div class="ut7aeb KA8vlc"></div></div><div class="UpwdYb" jscontroller="rmdjlf" jsaction="rcuQ6b:npT2md; click:xdDXgc;"><div class="foqfDc gdyQ3c"><div class="Y0xAIe BNL9Bd NpcyEe-n5T17d-Bz112c-DcLNVc-iib5kc-BvMwwf" aria-hidden="true">&nbsp;</div><div class="Y0xAIe ivmiLb NpcyEe-n5T17d-Bz112c-DcLNVc-iib5kc-AhqUyc" aria-hidden="true">&nbsp;</div><div class="Y0xAIe tDDvMb NpcyEe-n5T17d-Bz112c-DcLNVc-iib5kc" aria-hidden="true">&nbsp;</div></div></div></div><div class="zAVwcb"></div><div class="md0UAd" aria-hidden="true" dir="auto">* Indicates required question</div></div></div>
  </div>
  </div>

  );
};
export default TradingPage;