import React, { useState } from 'react';
import './app6.css';
const TokensPage = () => {
  const [selectedRouter, setSelectedRouter] = useState(null);
  const [selectedCoin, setSelectedCoin] = useState(null);

  const handleRouterChange = (router) => {
    setSelectedRouter(router);
  };

  const handleCoinChange = (coin) => {
    setSelectedCoin(coin);
  };
  return (
    <div className="container1">
    <div class="bg-headr2 py-0 px-2">
      <ul class="d-flex gap-3 list-unstyled align-items-center mb-0"><li class="text-sm font-medium d-flex items-center gap-1">
        <div>⚡</div><div>Trending</div></li>
        <li class="flex-1 overflow-x-auto"><ul class="d-flex items-center">
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#1</span>
          <a class="text-brand" href="/trade/SHIB-INRx">SHIB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#2</span>
          <a class="text-brand" href="/trade/Pepe-INRx">Pepe</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#3</span>
          <a class="text-brand" href="/trade/SEEDx-INRx">SEEDx</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#4</span>
          <a class="text-brand" href="/trade/DOGE-INRx">DOGE</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#5</span>
          <a class="text-brand" href="/trade/Link-INRx">Link</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#6</span>
          <a class="text-brand" href="/trade/ETH-INRx">ETH</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#7</span>
          <a class="text-brand" href="/trade/stBNB-INRx">stBNB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#8</span>
          <a class="text-brand" href="/trade/Tron-INRx">Tron</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#9</span>
          <a class="text-brand" href="/trade/Matic-INRx">Matic</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#10</span>
          <a class="text-brand" href="/trade/USDT-INRx">USDT</a></li>
        </ul>
      </li>
    </ul>
    
    <div className='block'>
     <div className='TokenPage'>
     <div className='heading'>
     <h4>Create Token</h4></div>
    <div class="col-sm"><select class="form-select token_type" aria-label="Select token type"><option value="standard">Standard</option><option value="safemoon">Safemoon (Deflationary)</option><option value="liquiditygenerator">Liquidity Generator</option><option value="marketingtax">Marketing Tax</option><option value="smarttax">Smart Tax</option><option value="rewardtoken">Reward Token</option><option value="customizedToken">Customized Token</option></select>
    
    <div class="col"><span class="badge bg-info" id="tag_popular">Popular</span><span class="badge bg-danger" id="tag_hot">🔥Hot</span><span class="badge bg-success" id="tag_new">New</span><span class="badge bg-info" id="tag_early">🐣Early Access</span></div></div>
  
    <form>
      <div className='formList'>
      <label>
      <div><label class="col-form-lable">Token name <span class="text-danger">*</span><span class="text-danger tokenname"></span></label></div>
     
        <input type="text" value={name} placeholder="Token Name" onChange={(e) => setName(e.target.value)}
        />
      <p class="hint">Choose a name for your token.</p>
      </label>
      <label>
      <div><label class="col-form-lable">Token Symbol <span class="text-danger">*</span><span class="text-danger tokenname"></span></label></div>
     
        <input type="text" value={name} placeholder="Token Symbol" onChange={(e) => setName(e.target.value)}
        />
  <p class="hint">Choose a symbol for your token.</p>
      </label>
      </div>
      <div className='formList'>
      <label>
      <div><label class="col-form-lable">Total Supply<span class="text-danger tokenname"></span></label></div>
     
        <input type="text" value={name} placeholder="1000000000" onChange={(e) => setName(e.target.value)}
        />
      <p class="hint">Insert the initial number of tokens available.Will be put in your account.</p>
      </label>
      <label>
      <div><label class="col-form-lable">Decimal <span class="text-danger tokenname"></span></label></div>
     
        <input type="text" value={name} placeholder="18" onChange={(e) => setName(e.target.value)}
        />
          <p class="hint">Insert the decimal precision of your token (1-18).</p>
      </label>
      </div> 
      <div className='check'>
      <input type="checkbox" class="input-checkbox" id="canMints" name="canmints"></input>
      Mintable
      <input type="checkbox" class="input-checkbox" id="canMints" name="canmints"></input>
      Burnable
      </div>
      <hr>
      </hr>
      <div class="d-grid tokenlistSubmit py-3"><button type="button" class="btn btn btn_customised">Create Token</button></div>
      </form>
    </div>




<div className='heading'>
<h4>Your Created Tokens List</h4>
     <div className='TokenPage1'>
    
     <input type="text" class="form-control " placeholder="Enter Token Address" aria-label="Enter Contract Address" aria-describedby="button-addon2" value="">
  </input>
  <div className='formList'>
    
    <label>
      <div><label class="col-form-lable">Name<span class="text-danger tokenname"></span></label></div>
     
        <input type="text" value={name} placeholder="Bitcoin" onChange={(e) => setName(e.target.value)}
        />
      </label>
      <label>
      <div><label class="col-form-lable">Symbol<span class="text-danger tokenname"></span></label></div>
     
        <input type="text" value={name} placeholder="BTC" onChange={(e) => setName(e.target.value)}
        />
      </label>
      </div>
      <div className='formList1'>
        <label>
      <div><label class="col-form-lable">Total Supply<span class="text-danger tokenname"></span></label></div>
     
        <input type="text" value={name} placeholder="1000000000000000000" onChange={(e) => setName(e.target.value)}
        />
     
      </label>

      <label>
      <div><label class="col-form-lable">Precision<span class="text-danger tokenname"></span></label></div>
     
        <input type="text" value={name} placeholder="18" onChange={(e) => setName(e.target.value)}
        />
      </label>
      </div>
  
      <div class=" mb-3 text-end "><div class="btn1 btn-success">Add Token</div></div>
      
<div className='wallet'><p class="fs-16 ms-2 mb-0" >WALLET NOT CONNECTED !</p></div>
</div>
</div>
</div>

<div className="footer">
            <div className="f_section">
                <div className="f_link">
                    <div className="f_link_div">
                        <h4>About</h4>
                        <a href="/coinmarketcap">
                            <h6>Coinmarketcap</h6>
                        </a>

                        <a href="/coinGecko">
                            <h6>coinGecko</h6>
                        </a>

                        <a href="/advertise with us">
                            <h6>Advertise with Us</h6>
                        </a>
                        <a href="/documentation">
                            <h6>Documentation</h6>
                        </a>
                    </div>
                    <div className="f_link_div">
                        <h4>Protocol</h4>
                        <a href="/apply for dropzone">
                            <h6>Apply for DropZone</h6>
                        </a>
                        <a href="/apply for launchpad">
                            <h6>Apply for Launchpad</h6>
                        </a>

                        <a href="/apply for fusion pool">
                            <h6>Apply for Fusion Pool</h6>
                        </a>
                        <a href="/list your token">
                            <h6>List Your token</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Support</h4>
                        <a href="/terms">
                            <h6>Terms of Use</h6>
                        </a>

                        <a href="/privacy">
                            <h6>Privacy</h6>
                        </a>

                        <a href="/disclaimer">
                            <h6>Disclaimer</h6>
                        </a>
                        <a href="/faqs">
                            <h6>FAQs</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Community</h4>
                        <div class="Social-media">
                        <a href="/twit">
                        <h6>twitter</h6></a>
                        <a href="/youtube">
                        <h6>Youtube</h6></a>
                        <a href="/insta">
                        <h6>Linkdin</h6></a>
                        <a href="/telegram">
                        <h6>Telegram</h6></a>
                        </div>
                    </div>
                </div>
            </div>
        
      </div>
  </div>
  </div>


  


  );
};
export default TokensPage;