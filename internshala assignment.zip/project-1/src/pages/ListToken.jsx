import React, { useState } from 'react';

function Exchange() {
  const [email, setEmail] = useState('');
  const [emailRecord, setEmailRecord] = useState(false);

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handleEmailRecordChange = (event) => {
    setEmailRecord(event.target.checked);
  };

  return (
    <div className="container">
      <div className="header">
       <img src="https://ximg.magic.store/kreHY_OKtKXVDr5xWAJW3O9TtUGvNgWubDCzRuovO9M/rs:fill:1200:550:0/dpr:1/g:ce/f:webp/q:60/czM6Ly9wcm9kLW1hZ2ljLXN0b3JlLWltYWdlcy81MTBlNWEwZS1hOWM5LTRjY2MtODIzYi1lYWQ3NzExN2FjODE"></img>
        </div>
      </div>
  );
}

export default Exchange;