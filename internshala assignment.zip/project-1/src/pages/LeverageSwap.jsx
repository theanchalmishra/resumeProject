import React, { useState } from "react";
import "./app2.css";

function Leverage() {
  const [selectedRouter, setSelectedRouter] = useState("PancakeSwap");
  const [selectedToken, setSelectedToken] = useState("");
  const [amountToPay, setAmountToPay] = useState("");
  const [amountToReceive, setAmountToReceive] = useState("");

  const handleRouterChange = (event) => {
    setSelectedRouter(event.target.value);
  };

  const handleTokenChange = (event) => {
    setSelectedToken(event.target.value);
  };

  const handleAmountToPayChange = (event) => {
    setAmountToPay(event.target.value);
  };

  const handleAmountToReceiveChange = (event) => {
    setAmountToReceive(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log("Selected router:", selectedRouter);
    console.log("Selected token:", selectedToken);
    console.log("Amount to pay:", amountToPay);
    console.log("Amount to receive:", amountToReceive);
    alert(
      "Swap is not implemented yet. This is just a placeholder for demonstration."
    );
  };

  return (
    <div className="app-container">
      <div className="header">
        <input type="text" placeholder="Type here to search..." />
      </div>
      <div class="bg-headr2 py-0 px-2">
      <ul class="d-flex gap-3 list-unstyled align-items-center mb-0"><li class="text-sm font-medium d-flex items-center gap-1">
        <div>⚡</div><div>Trending</div></li>
        <li class="flex-1 overflow-x-auto"><ul class="d-flex items-center">
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#1</span>
          <a class="text-brand" href="/trade/SHIB-INRx">SHIB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#2</span>
          <a class="text-brand" href="/trade/Pepe-INRx">Pepe</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#3</span>
          <a class="text-brand" href="/trade/SEEDx-INRx">SEEDx</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#4</span>
          <a class="text-brand" href="/trade/DOGE-INRx">DOGE</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#5</span>
          <a class="text-brand" href="/trade/Link-INRx">Link</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#6</span>
          <a class="text-brand" href="/trade/ETH-INRx">ETH</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#7</span>
          <a class="text-brand" href="/trade/stBNB-INRx">stBNB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#8</span>
          <a class="text-brand" href="/trade/Tron-INRx">Tron</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#9</span>
          <a class="text-brand" href="/trade/Matic-INRx">Matic</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#10</span>
          <a class="text-brand" href="/trade/USDT-INRx">USDT</a></li>
        </ul>
      </li>
    </ul>
  </div>
     <div className="swap-form">
        <form onSubmit={handleSubmit}>
          <div className="router-selection">
            <h3>Select Router</h3>
            <div className="router-options">
              <label htmlFor="pancakeSwap">
                <input
                  type="radio"
                  id="pancakeSwap"
                  name="router"
                  value="PancakeSwap"
                  checked={selectedRouter === "PancakeSwap"}
                  onChange={handleRouterChange}
                />
                PancakeSwap
              </label>
              <label htmlFor="uniSwap">
                <input
                  type="radio"
                  id="uniSwap"
                  name="router"
                  value="UniSwap"
                  checked={selectedRouter === "UniSwap"}
                  onChange={handleRouterChange}
                />
                UniSwap
              </label>
            </div>
          </div>
          <div className="input-fields">
            <div className="field">
              <label htmlFor="amountToPay">You pay</label>
              <input
                type="number"
                id="amountToPay"
                placeholder="0"
                value={amountToPay}
                onChange={handleAmountToPayChange}
              />
              
            </div>
            <div className="field">
              <label htmlFor="amountToReceive">You receive</label>
              <input
                type="number"
                id="amountToReceive"
                placeholder="0"
                value={amountToReceive}
                onChange={handleAmountToReceiveChange}
                readOnly
              />
              <span className="currency">INRx</span>
            </div>
          </div>
          <div className="error-message">
            Insufficient liquidity for this trade
          </div>
        </form>
        </div>
        <div className="footer">
            <div className="f_section">
                <div className="f_link">
                    <div className="f_link_div">
                        <h4>About</h4>
                        <a href="/coinmarketcap">
                            <h6>Coinmarketcap</h6>
                        </a>

                        <a href="/coinGecko">
                            <h6>coinGecko</h6>
                        </a>

                        <a href="/advertise with us">
                            <h6>Advertise with Us</h6>
                        </a>
                        <a href="/documentation">
                            <h6>Documentation</h6>
                        </a>
                    </div>
                    <div className="f_link_div">
                        <h4>Protocol</h4>
                        <a href="/apply for dropzone">
                            <h6>Apply for DropZone</h6>
                        </a>
                        <a href="/apply for launchpad">
                            <h6>Apply for Launchpad</h6>
                        </a>

                        <a href="/apply for fusion pool">
                            <h6>Apply for Fusion Pool</h6>
                        </a>
                        <a href="/list your token">
                            <h6>List Your token</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Support</h4>
                        <a href="/terms">
                            <h6>Terms of Use</h6>
                        </a>

                        <a href="/privacy">
                            <h6>Privacy</h6>
                        </a>

                        <a href="/disclaimer">
                            <h6>Disclaimer</h6>
                        </a>
                        <a href="/faqs">
                            <h6>FAQs</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Community</h4>
                        <div class="Social-media">
                        <a href="/twit">
                        <h6>twitter</h6></a>
                        <a href="/youtube">
                        <h6>Youtube</h6></a>
                        <a href="/insta">
                        <h6>Linkdin</h6></a>
                        <a href="/telegram">
                        <h6>Telegram</h6></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     
    
        </div>
      
  );
}

export default Leverage ;