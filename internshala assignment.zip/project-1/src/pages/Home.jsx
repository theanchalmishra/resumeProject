import React, { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/footer';
import Seedx from '../components/Seedx';
import Header from '../components/Header';

import UserData from '../components/UserData';
import { getTokens } from '../apishanlers/apis';
const Home = () => {
    const [list, setList] = useState([])

    useEffect(() => {
        (async () => {
            try {
                const arr = await getTokens();
                setList(arr);
                console.log(arr, "token list")
            } catch (e) {
                console.log(e, "Error in usesdsf")
            }
        })();

    }, [])

    return (
        <div className='container1'>

        <div className="App m-0 p-0 bg-dark">
            <div className=" m-0 p-0">
                <Header />
            
                {/* <Navbar/> */}
                
              
        

            <div className="container1">
          
                <table class="market-table">
                    <tr>
                        <th class="market-cell">Name</th>
                        <th class="market-cell">Price</th>
                        <th class="market-cell">Change (1h)</th>
                        <th class="market-cell">24h Volume</th>
                        <th class="market-cell">Trade</th>
                    </tr>
                    <UserData users={list ? list : []} />
                </table>
            </div>
          </div>
            <div className='Footer'>
                <div className='footer'>

                </div>
            </div>

            <div className="container1">
            <div className="logo" align="center">
                <img src={'https://seedx.app/image/tablet_view.gif'} height='350px' width='800px' alt="logo" />
                <Seedx />
        
            </div> 
    </div>
            <Footer />
        </div>
        </div>
         
    )
};

export default Home;