/*import "../App.css";
function Blog(){
    return (
    <BrowserRouter>
    <Routes>
    <Route path="menu" element={<Home />} />
        <Route path="menu" element={<div>Menu Page</div>} />
        <Route path="exchange" element={<div>Exchange Page</div>} />
    </Routes>
    </BrowserRouter>
    );
}

export default Blog;*/