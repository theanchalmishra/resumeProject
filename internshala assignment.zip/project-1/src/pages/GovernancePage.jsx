import React, { useState } from 'react';
import './app4.css';
import Footer from '../components/footer';
const Governance = () => {
  const [selectedRouter, setSelectedRouter] = useState(null);
  const [selectedCoin, setSelectedCoin] = useState(null);

  const handleRouterChange = (router) => {
    setSelectedRouter(router);
  };

  const handleCoinChange = (coin) => {
    setSelectedCoin(coin);
  };
  return (
<div className="container1">
    <div class="bg-headr2 py-0 px-2">
      <ul class="d-flex gap-3 list-unstyled align-items-center mb-0"><li class="text-sm font-medium d-flex items-center gap-1">
        <div>⚡</div><div>Trending</div></li>
        <li class="flex-1 overflow-x-auto"><ul class="d-flex items-center">
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#1</span>
          <a class="text-brand" href="/trade/SHIB-INRx">SHIB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#2</span>
          <a class="text-brand" href="/trade/Pepe-INRx">Pepe</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#3</span>
          <a class="text-brand" href="/trade/SEEDx-INRx">SEEDx</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#4</span>
          <a class="text-brand" href="/trade/DOGE-INRx">DOGE</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#5</span>
          <a class="text-brand" href="/trade/Link-INRx">Link</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#6</span>
          <a class="text-brand" href="/trade/ETH-INRx">ETH</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#7</span>
          <a class="text-brand" href="/trade/stBNB-INRx">stBNB</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#8</span>
          <a class="text-brand" href="/trade/Tron-INRx">Tron</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#9</span>
          <a class="text-brand" href="/trade/Matic-INRx">Matic</a></li>
          <li class="px-2 py-2 d-flex gap-2 text-sm whitespace-nowrap"><span class="font-medium">#10</span>
          <a class="text-brand" href="/trade/USDT-INRx">USDT</a></li>
        </ul>
      </li>
    </ul></div>
    <div className='Slide'>
      <div className='slide1'>
    <h3 class="fw-bold text-shadow mb-1">DAO GOVERNING </h3></div>
      </div>   
      <div className='linkSec'>
        <div className="link">
        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 1024 1024" height="1em" width="1em"  color="gray" xmlns="http://www.w3.org/2000/svg"><path d="M854.6 288.6L639.4 73.4c-6-6-14.1-9.4-22.6-9.4H192c-17.7 0-32 14.3-32 32v832c0 17.7 14.3 32 32 32h640c17.7 0 32-14.3 32-32V311.3c0-8.5-3.4-16.7-9.4-22.7zM790.2 326H602V137.8L790.2 326zm1.8 562H232V136h302v216a42 42 0 0 0 42 42h216v494zM504 618H320c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h184c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8zM312 490v48c0 4.4 3.6 8 8 8h384c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8H320c-4.4 0-8 3.6-8 8z"></path></svg>
    
        <span>https://www.bscscan.com/tokenholdings?a=0xeee01c3f09697c97a1dda18dce414f030aacf736</span></div>
      </div>

      <div className='Sections'>
        <div className='cards1'>
      <div class="col-lg-3"><div class="row"><div class="col-lg-12"><div class="cards1 mb-2"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2"><div> <h6 class="textcolor mb-0"> <i class="fa fa-wallet fs-14"></i> Balance</h6></div><div></div></div><div class="d-flex justify-content-between align-items-center mt-5"><div><div class="d-flex align-items-center"><div class="h2">₹0.00</div></div></div></div><div class="d-flex justify-content-between align-items-end mt-5"><div class="adv_serch"><div class="dropdown"><div class="text-muted">Today</div></div><span>₹0.00</span></div><div class="  mb-0"> <span><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" aria-hidden="true" class="text-pink" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 2.25a.75.75 0 01.75.75v16.19l2.47-2.47a.75.75 0 111.06 1.06l-3.75 3.75a.75.75 0 01-1.06 0l-3.75-3.75a.75.75 0 111.06-1.06l2.47 2.47V3a.75.75 0 01.75-.75z" clip-rule="evenodd"></path></svg> <span class="text-pink">0%</span></span></div></div></div></div></div></div></div>
      </div>
      <div className='cards1'>
      <div class="col-lg-3"><div class="row"><div class="col-lg-12"><div class="cards1 mb-2"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2"><div> <h6 class="textcolor mb-0"> <i class="fa fa-wallet fs-14"></i> Balance</h6></div><div></div></div><div class="d-flex justify-content-between align-items-center mt-5"><div><div class="d-flex align-items-center"><div class="h2">₹0.00</div></div></div></div><div class="d-flex justify-content-between align-items-end mt-5"><div class="adv_serch"><div class="dropdown"><div class="text-muted">Today</div></div><span>₹0.00</span></div><div class="  mb-0"> <span><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" aria-hidden="true" class="text-pink" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 2.25a.75.75 0 01.75.75v16.19l2.47-2.47a.75.75 0 111.06 1.06l-3.75 3.75a.75.75 0 01-1.06 0l-3.75-3.75a.75.75 0 111.06-1.06l2.47 2.47V3a.75.75 0 01.75-.75z" clip-rule="evenodd"></path></svg> <span class="text-pink">0%</span></span></div></div></div></div></div></div></div>
      </div>
      <div className='cards1'>
      <div class="col-lg-3"><div class="row"><div class="col-lg-12"><div class="cards1 mb-2"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2"><div> <h6 class="textcolor mb-0"> <i class="fa fa-wallet fs-14"></i> Balance</h6></div><div></div></div><div class="d-flex justify-content-between align-items-center mt-5"><div><div class="d-flex align-items-center"><div class="h2">₹0.00</div></div></div></div><div class="d-flex justify-content-between align-items-end mt-5"><div class="adv_serch"><div class="dropdown"><div class="text-muted">Today</div></div><span>₹0.00</span></div><div class="  mb-0"> <span><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" aria-hidden="true" class="text-pink" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 2.25a.75.75 0 01.75.75v16.19l2.47-2.47a.75.75 0 111.06 1.06l-3.75 3.75a.75.75 0 01-1.06 0l-3.75-3.75a.75.75 0 111.06-1.06l2.47 2.47V3a.75.75 0 01.75-.75z" clip-rule="evenodd"></path></svg> <span class="text-pink">0%</span></span></div></div></div></div></div></div></div>
      </div>
      <div className='cards1'>
      <div class="col-lg-3"><div class="row"><div class="col-lg-12"><div class="cards1 mb-2"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2"><div> <h6 class="textcolor mb-0"> <i class="fa fa-wallet fs-14"></i> Balance</h6></div><div></div></div><div class="d-flex justify-content-between align-items-center mt-5"><div><div class="d-flex align-items-center"><div class="h2">₹0.00</div></div></div></div><div class="d-flex justify-content-between align-items-end mt-5"><div class="adv_serch"><div class="dropdown"><div class="text-muted">Today</div></div><span>₹0.00</span></div><div class="  mb-0"> <span><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" aria-hidden="true" class="text-pink" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 2.25a.75.75 0 01.75.75v16.19l2.47-2.47a.75.75 0 111.06 1.06l-3.75 3.75a.75.75 0 01-1.06 0l-3.75-3.75a.75.75 0 111.06-1.06l2.47 2.47V3a.75.75 0 01.75-.75z" clip-rule="evenodd"></path></svg> <span class="text-pink">0%</span></span></div></div></div></div></div></div></div>
      </div></div>
      <div className='Section3'>
        <img src="https://img.freepik.com/premium-vector/vip-membership-card-with-golden-crown_22052-1658.jpg" height="150px" width="400px" ></img>
        <div className='SectionPart'>
        <div class="col-lg-8"><div class="card-body p-0"><div class="col-md-9  mob_order_2"><div class="row mb-2 mt-3"><div class="col-lg-6 col-6"><div class="fs-14"><div class="pe-2"> ₹0.00</div><div class="text-muted">Deligator Pool</div></div></div><div class="col-lg-6 col-6"><div class="fs-14"><div class="pe-2"></div><div class="text-muted">Deligator</div></div></div></div><div class="row"><div class="col-lg-6 col-6"><div class="fs-14"><div class="pe-2 "> ₹340.33</div><div class="text-muted">Voter Pool</div></div></div><div class="col-lg-6 col-6"><div class="fs-14"><div class="pe-2"></div><div class="text-muted">Voter</div></div></div></div></div><div class="col-md-3 prosal_img mob_order_1 "><div class="text-center"></div></div></div></div></div>
      <div className='imgBar'><img src="https://seedx.app/image/reward.svg" height="150px"></img></div>
      </div>
      <div className='Section4'>
        <div className='textPart'><div class="d-flex justify-content-between align-items-end mt-4"><div class="adv_serch"><span>Staking</span><div class="dropdown"><div class="text-muted">Earn rewards for contributing to safety.</div></div></div><div class="fs-14 mb-0"> </div></div>
      </div>
      </div>
    
      <div className="SectionPart1">
        <div className="cards">
        <div class="col-md-12"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2"><div> <h5>Circulating Supply</h5></div><div></div></div><div class="d-flex justify-content-between align-items-center mt-4 pt-2 fs-16"><div><div class="d-flex align-items-center"><span>100 M</span><img src="/image/seedx-logo.png"></img></div><p class=" fs-14 mb-0">Pool Size</p></div><div><div class="d-flex align-items-center"><span>$0.00</span></div><p class=" fs-14 mb-0"> MarketCap</p></div><div>₹ 2.17<p class=" fs-14 mb-0"> Price</p></div></div></div></div>
        </div>
        <div className="cards">
        <div class="card-body"><h5 class="">Governance Supply</h5></div>
        <div class="card-body"><h6 class="">21,189,841.44</h6>
        <div className='ProgressBar'>
        <div style={{ width: '100%', backgroundColor: 'gray' }}><div style={{ width: '20%', height: '5px', background: 'blue', justifyContent:'center'}}></div></div>
        
        </div>
        </div>
        <div class="card-body"><h6 class="">15.24% Complete</h6></div>
       </div>

        <div className="cards">
        <div class="card-body"><p class=" mb-0">Propose an idea</p> <h5 class="mb-0">Suggest a new pool</h5></div>
        
        <div class="card-body">
        <div class="fs-16"><a href="https://forum.seedx.community/" target="_blank"><button class="btn btn_customised me-2 mb-2">Forum <i class="fas fa-share-square ms-1 fs-12"></i></button></a>
       
        <a href="https://forum.seedx.community/" target="_blank"><button class="btn btn_customised me-2 mb-2">Discord <i class="fas fa-share-square ms-1 fs-12"></i></button></a></div>
        </div></div>
        
      </div>
      <div className='Section5'>
        <div class="d-flex justify-content-between align-items-end mt-4"><div class="adv_serch"><span>Trading Rewards</span><div class="dropdown"><div class="text-muted">Earn rewards for trading on the SEEDx exchange.</div></div></div><div class="fs-14 mb-0"> </div></div>
      </div>
      
        <div className='SectionPart1'>
        <div className="cards3">
        <div class="card-body"><h5 class=" mb-1">Voting Countdown</h5><div class=""><span class="mob-font">00:00:00</span><p class=" fs-14 mb-0">until the next epoch on <span class="">22-Aug, 3:32:29 pm</span>.</p></div></div>
        </div>
        <div className="cards3">
        <div class="card-body"><h5 class="">Proposal Power</h5>
        
        <button class="market-bt">Inactive</button>
        </div></div>
        <div className="cards3">
        <div class="card-body"><h5 class="">Voting Power</h5><div class="dashboard-card"><div class="lead mt-2">0</div></div></div>
        </div></div>
      
      <div className='f_Section'>
     
      <div className="footers">
            <div className="f_section">
                <div className="f_link">
                    <div className="f_link_div">
                        <h4>About</h4>
                        <a href="/coinmarketcap">
                            <h6>Coinmarketcap</h6>
                        </a>


                        <a href="/coinGecko">
                            <h6>coinGecko</h6>
                        </a>

                        <a href="/advertise with us">
                            <h6>Advertise with Us</h6>
                        </a>
                        <a href="/documentation">
                            <h6>Documentation</h6>
                        </a>
                    </div>
                    <div className="f_link_div">
                        <h4>Protocol</h4>
                        <a href="/apply for dropzone">
                            <h6>Apply for DropZone</h6>
                        </a>
                        <a href="/apply for launchpad">
                            <h6>Apply for Launchpad</h6>
                        </a>

                        <a href="/apply for fusion pool">
                            <h6>Apply for Fusion Pool</h6>
                        </a>
                        <a href="/list your token">
                            <h6>List Your token</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Support</h4>
                        <a href="/terms">
                            <h6>Terms of Use</h6>
                        </a>

                        <a href="/privacy">
                            <h6>Privacy</h6>
                        </a>

                        <a href="/disclaimer">
                            <h6>Disclaimer</h6>
                        </a>
                        <a href="/faqs">
                            <h6>FAQs</h6>
                        </a>
                    </div>

                    <div className="f_link_div">
                        <h4>Community</h4>
                        <div class="Social-media">
                        <a href="/twit">
                        <h6>twitter</h6></a>
                        <a href="/youtube">
                        <h6>Youtube</h6></a>
                        <a href="/insta">
                        <h6>Linkdin</h6></a>
                        <a href="/telegram">
                        <h6>Telegram</h6></a>
                        </div>
                    </div>
                </div>
           </div>
      </div>
  </div>
  </div>

    
  );
};

export default Governance;