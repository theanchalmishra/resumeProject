import React from "react";
const Exchange = () => {
    return (
        <div>Exchange</div>
        
    );
}
export default Exchange;